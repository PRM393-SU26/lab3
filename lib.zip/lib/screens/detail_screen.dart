import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/reading_list_provider.dart';
import '../services/search_provider.dart';
import '../utils/link_launcher.dart';
import 'author_detail_screen.dart';
import 'source_detail_screen.dart';

class DetailScreen extends StatefulWidget {
  final String workId;
  const DetailScreen({super.key, required this.workId});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<SearchProvider>().loadWorkDetail(widget.workId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SearchProvider>();
    final theme = Theme.of(context);
    final work = provider.selectedWork;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Publication Detail'),
        actions: [
          if (work != null) ...[
            Consumer<ReadingListProvider>(
              builder: (context, readingList, child) {
                final isSaved = readingList.contains(work.id);
                return IconButton(
                  icon: Icon(
                    isSaved ? Icons.bookmark : Icons.bookmark_border,
                    color: isSaved ? Colors.amber : null,
                  ),
                  tooltip: isSaved ? 'Remove Bookmark' : 'Bookmark',
                  onPressed: () async {
                    await readingList.toggle(work);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            isSaved
                                ? 'Removed bookmark (Cloud deleted)'
                                : 'Bookmarked! (Saved to Cloud)',
                          ),
                          duration: const Duration(seconds: 2),
                        ),
                      );
                    }
                  },
                );
              },
            ),
            Consumer<ReadingListProvider>(
              builder: (context, readingList, child) {
                final isSaved = readingList.contains(work.id);
                return IconButton(
                  icon: Icon(
                    isSaved ? Icons.favorite : Icons.favorite_border,
                    color: isSaved ? Colors.red : null,
                  ),
                  tooltip: isSaved ? 'Remove Favorite' : 'Favorite',
                  onPressed: () async {
                    await readingList.toggle(work);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            isSaved
                                ? 'Removed favorite (Cloud deleted)'
                                : 'Added to Favorites! (Saved to Cloud)',
                          ),
                          duration: const Duration(seconds: 2),
                        ),
                      );
                    }
                  },
                );
              },
            ),
          ],
        ],
      ),
      body: Builder(
        builder: (context) {
          if (provider.detailState == LoadState.loading) {
            return const Center(child: CircularProgressIndicator());
          }
          if (provider.detailState == LoadState.error) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.error_outline, size: 48, color: theme.colorScheme.error),
                  const SizedBox(height: 16),
                  Text(
                    provider.errorMessage ?? 'Failed to load details',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {
                      context.read<SearchProvider>().loadWorkDetail(widget.workId);
                    },
                    child: const Text('Retry'),
                  ),
                ],
              ),
            );
          }
          if (work == null) {
            return const Center(child: Text('No details found'));
          }

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Title
                Text(
                  work.title,
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
                const SizedBox(height: 12),
                
                // Badges row
                Row(
                  children: [
                    if (work.isOpenAccess) ...[
                      Chip(
                        label: const Text('Open Access'),
                        backgroundColor: Colors.green.shade100,
                        labelStyle: TextStyle(color: Colors.green.shade800, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(width: 8),
                    ],
                    if (work.type != null) ...[
                      Chip(
                        label: Text(work.type!.replaceAll('-', ' ').toUpperCase()),
                        backgroundColor: theme.colorScheme.primaryContainer,
                        labelStyle: TextStyle(color: theme.colorScheme.onPrimaryContainer),
                      ),
                    ],
                  ],
                ),
                const Divider(height: 24),
                
                // Citation and Year stats row
                Card(
                  elevation: 0,
                  color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.4),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildStatTile(
                          context,
                          Icons.format_quote,
                          '${work.citedByCount}',
                          'Citations',
                        ),
                        _buildStatTile(
                          context,
                          Icons.calendar_today,
                          work.publicationYear != null ? '${work.publicationYear}' : 'N/A',
                          'Year Published',
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Journal / Source Info
                if (work.primarySource != null) ...[
                  Text('Source', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const CircleAvatar(
                      child: Icon(Icons.menu_book),
                    ),
                    title: Text(work.primarySource!.displayName),
                    subtitle: Text(work.primarySource!.type ?? 'Journal'),
                    trailing: work.primarySource!.id != null
                        ? const Icon(Icons.chevron_right)
                        : null,
                    onTap: work.primarySource!.id != null
                        ? () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => SourceDetailScreen(
                                  sourceId: work.primarySource!.id!,
                                  sourceName: work.primarySource!.displayName,
                                ),
                              ),
                            );
                          }
                        : null,
                  ),
                  const Divider(height: 24),
                ],

                // Authors and institutions
                if (work.authorships.isNotEmpty) ...[
                  Text('Authors', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: work.authorships.length,
                    itemBuilder: (context, idx) {
                      final auth = work.authorships[idx];
                      return InkWell(
                        onTap: auth.authorId != null
                            ? () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => AuthorDetailScreen(
                                      authorId: auth.authorId!,
                                      authorName: auth.authorName,
                                    ),
                                  ),
                                );
                              }
                            : null,
                        borderRadius: BorderRadius.circular(8),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Icon(Icons.person, size: 18, color: Colors.grey),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      auth.authorName,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: auth.authorId != null
                                            ? theme.colorScheme.primary
                                            : null,
                                      ),
                                    ),
                                    if (auth.institutionName != null)
                                      Text(
                                        auth.institutionName!,
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: theme.colorScheme.onSurfaceVariant,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              if (auth.authorId != null)
                                Icon(Icons.chevron_right,
                                    size: 18, color: theme.colorScheme.outline),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                  const Divider(height: 24),
                ],

                // DOI
                if (work.doi != null) ...[
                  Text('DOI', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  InkWell(
                    onTap: () => LinkLauncher.openDoi(context, work.doi!),
                    borderRadius: BorderRadius.circular(8),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              work.doi!,
                              style: TextStyle(
                                color: theme.colorScheme.primary,
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ),
                          Icon(
                            Icons.open_in_new,
                            size: 16,
                            color: theme.colorScheme.primary,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const Divider(height: 24),
                ],

                // Abstract text
                Text('Abstract', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(
                  work.abstractText != null && work.abstractText!.trim().isNotEmpty
                      ? work.abstractText!
                      : 'No abstract available for this publication.',
                  style: const TextStyle(height: 1.5, fontSize: 14),
                  textAlign: TextAlign.justify,
                ),

                if (provider.relatedWorks.isNotEmpty) ...[
                  const Divider(height: 32),
                  Text(
                    'Citing Papers',
                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: provider.relatedWorks.length,
                    itemBuilder: (context, idx) {
                      final related = provider.relatedWorks[idx];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          title: Text(
                            related.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            '${related.publicationYear ?? 'N/A'} · ${related.citedByCount} citations',
                          ),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => DetailScreen(workId: related.id),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
                ],
                const SizedBox(height: 40),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildStatTile(BuildContext context, IconData icon, String value, String label) {
    final theme = Theme.of(context);
    return Column(
      children: [
        Icon(icon, color: theme.colorScheme.primary, size: 28),
        const SizedBox(height: 8),
        Text(
          value,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: theme.colorScheme.onSurface,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}