import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/reading_list_provider.dart';
import '../providers/settings_provider.dart';
import '../services/search_provider.dart';
import '../services/analytics_service.dart';
import 'detail_screen.dart';
import 'reading_list_screen.dart';
import 'trend_screen.dart';
import 'dashboard_screen.dart';
import 'author_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen>
    with SingleTickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _searchFocusNode = FocusNode();
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 7, vsync: this);
    _tabController.addListener(() {
      setState(() {});
    });
    _searchFocusNode.addListener(() => setState(() {}));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<SearchProvider>().loadGlobalTopAuthors();
      context.read<SearchProvider>().loadPersonalizedSuggestions();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    _searchFocusNode.dispose();
    _tabController.dispose();
    super.dispose();
  }

  void _performSearch() {
    final query = _searchController.text.trim();
    if (query.isNotEmpty) {
      context.read<SearchProvider>().clearSuggestions();
      context.read<SearchProvider>().search(query);
      context.read<SearchProvider>().loadTrendAnalysis();
      context.read<SearchProvider>().loadDashboard();
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<SearchProvider>();
    final settings = context.watch<SettingsProvider>();
    final theme = Theme.of(context);

    if (provider.globalTopAuthorsState == LoadState.idle) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.read<SearchProvider>().loadGlobalTopAuthors();
      });
    }

    return Scaffold(
      appBar: AppBar(
        leading: provider.currentTopic.isNotEmpty
            ? IconButton(
                icon: const Icon(Icons.arrow_back),
                tooltip: 'Back to Main',
                onPressed: () {
                  _searchController.clear();
                  context.read<SearchProvider>().resetSearch();
                  _tabController.index = 0;
                },
              )
            : null,
        title: const Text('Journal Trend Analyzer'),
        actions: [
          if (provider.currentTopic.isNotEmpty) _buildNavigationDropdown(theme),
          IconButton(
            icon: const Icon(Icons.bookmarks_outlined),
            tooltip: 'Reading List',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ReadingListScreen()),
            ),
          ),
          if (provider.currentTopic.isEmpty)
            IconButton(
              icon: const Icon(Icons.settings_outlined),
              tooltip: 'Settings',
              onPressed: () => _showSettingsModal(context),
            ),
        ],
      ),
      body: Column(
        children: [
          // Search & Filter Panel
          ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.sizeOf(context).height * 0.45,
            ),
            child: SingleChildScrollView(
              child: Container(
                padding: const EdgeInsets.all(16.0),
                color: theme.colorScheme.surface,
                child: Column(
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              TextField(
                                key: const Key('searchField'),
                                controller: _searchController,
                                focusNode: _searchFocusNode,
                                decoration: InputDecoration(
                                  hintText:
                                      'Search topic (e.g. machine learning)',
                                  prefixIcon: const Icon(Icons.search),
                                  suffixIcon: _searchController.text.isNotEmpty
                                      ? IconButton(
                                          icon: const Icon(Icons.clear),
                                          onPressed: () {
                                            _searchController.clear();
                                            context
                                                .read<SearchProvider>()
                                                .clearSuggestions();
                                            setState(() {});
                                          },
                                        )
                                      : null,
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  filled: true,
                                  fillColor: theme
                                      .colorScheme
                                      .surfaceContainerHighest
                                      .withOpacity(0.3),
                                ),
                                onChanged: (val) {
                                  context
                                      .read<SearchProvider>()
                                      .fetchSuggestions(val);
                                  setState(() {});
                                },
                                onSubmitted: (_) {
                                  context
                                      .read<SearchProvider>()
                                      .clearSuggestions();
                                  _performSearch();
                                },
                              ),
                              if (_searchFocusNode.hasFocus &&
                                  provider.suggestions.isEmpty &&
                                  provider.searchHistory.isNotEmpty)
                                Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Wrap(
                                    spacing: 6.0,
                                    runSpacing: 4.0,
                                    children: provider.searchHistory.map((
                                      query,
                                    ) {
                                      return InputChip(
                                        visualDensity: VisualDensity.compact,
                                        materialTapTargetSize:
                                            MaterialTapTargetSize.shrinkWrap,
                                        avatar: const Icon(
                                          Icons.history,
                                          size: 14,
                                        ),
                                        label: Text(
                                          query,
                                          style: theme.textTheme.bodySmall,
                                        ),
                                        onPressed: () {
                                          _searchController.text = query;
                                          _performSearch();
                                        },
                                      );
                                    }).toList(),
                                  ),
                                ),
                              if (provider.suggestions.isNotEmpty)
                                Padding(
                                  padding: const EdgeInsets.only(top: 4),
                                  child: Material(
                                    elevation: 4,
                                    borderRadius: BorderRadius.circular(12),
                                    color: theme.colorScheme.surface,
                                    clipBehavior: Clip.antiAlias,
                                    child: ConstrainedBox(
                                      constraints: const BoxConstraints(
                                        maxHeight: 180,
                                      ),
                                      child: ListView.separated(
                                        shrinkWrap: true,
                                        padding: EdgeInsets.zero,
                                        itemCount: provider.suggestions.length,
                                        separatorBuilder: (_, _) => Divider(
                                          height: 1,
                                          color:
                                              theme.colorScheme.outlineVariant,
                                        ),
                                        itemBuilder: (context, index) {
                                          final suggestion =
                                              provider.suggestions[index];
                                          return ListTile(
                                            dense: true,
                                            visualDensity:
                                                VisualDensity.compact,
                                            leading: const Icon(
                                              Icons.search,
                                              size: 18,
                                            ),
                                            title: Text(
                                              suggestion,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                            onTap: () {
                                              _searchController.text =
                                                  suggestion;
                                              context
                                                  .read<SearchProvider>()
                                                  .clearSuggestions();
                                              setState(() {});
                                              _performSearch();
                                            },
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        SizedBox(
                          height: 48,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: theme.colorScheme.primary,
                              foregroundColor: theme.colorScheme.onPrimary,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            onPressed: _performSearch,
                            child: const Text('Search'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Results Area
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                Column(
                  children: [
                    if (provider.works.isNotEmpty ||
                        (provider.searchState == LoadState.loading &&
                            provider.currentTopic.isNotEmpty))
                      _buildSortBar(provider, theme),
                    Expanded(
                      child: _buildResultsList(provider, theme, settings),
                    ),
                  ],
                ),
                provider.currentTopic.isEmpty
                    ? _buildResultsList(provider, theme, settings)
                    : YearlyTrendTab(provider: provider),
                provider.currentTopic.isEmpty
                    ? _buildResultsList(provider, theme, settings)
                    : const DashboardScreen(),
                provider.currentTopic.isEmpty
                    ? _buildResultsList(provider, theme, settings)
                    : TopPapersTab(provider: provider),
                provider.currentTopic.isEmpty
                    ? _buildResultsList(provider, theme, settings)
                    : TopJournalsTab(provider: provider),
                provider.currentTopic.isEmpty
                    ? _buildResultsList(provider, theme, settings)
                    : TopAuthorsTab(provider: provider),
                provider.currentTopic.isEmpty
                    ? _buildResultsList(provider, theme, settings)
                    : CountriesTab(provider: provider),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavigationDropdown(ThemeData theme) {
    final List<Map<String, dynamic>> items = [
      {'title': 'Paper', 'icon': Icons.article},
      {'title': 'Yearly Trend', 'icon': Icons.show_chart},
      {'title': 'Dashboard', 'icon': Icons.dashboard},
      {'title': 'Top Papers', 'icon': Icons.workspace_premium},
      {'title': 'Journals', 'icon': Icons.menu_book},
      {'title': 'Authors', 'icon': Icons.people},
      {'title': 'Countries', 'icon': Icons.public},
    ];

    final currentItem = items[_tabController.index];

    return PopupMenuButton<int>(
      initialValue: _tabController.index,
      color: theme.colorScheme.surface,
      tooltip: 'Navigate',
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 12.0),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(currentItem['icon'] as IconData, color: Colors.white),
            const Icon(Icons.arrow_drop_down, color: Colors.white),
          ],
        ),
      ),
      onSelected: (int newIndex) {
        setState(() {
          _tabController.index = newIndex;
        });
      },
      itemBuilder: (BuildContext context) {
        return items.asMap().entries.map((entry) {
          final idx = entry.key;
          final item = entry.value;
          return PopupMenuItem<int>(
            value: idx,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  item['icon'] as IconData,
                  color: theme.colorScheme.primary,
                ),
                const SizedBox(width: 12),
                Text(
                  item['title'] as String,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          );
        }).toList();
      },
    );
  }

  Widget _buildSortBar(SearchProvider provider, ThemeData theme) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withOpacity(0.3),
        border: Border(
          bottom: BorderSide(color: theme.colorScheme.outlineVariant),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Icon(
                Icons.sort,
                size: 20,
                color: theme.colorScheme.onSurfaceVariant,
              ),
              const SizedBox(width: 8),
              Text(
                'Sort by:',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<WorkSortOption>(
                    isExpanded: true,
                    isDense: true,
                    value: provider.sortBy,
                    items: WorkSortOption.values
                        .map(
                          (option) => DropdownMenuItem(
                            value: option,
                            child: Text(
                              option.label,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: provider.searchState == LoadState.loading
                        ? null
                        : (option) {
                            if (option != null) {
                              context.read<SearchProvider>().setSortBy(option);
                            }
                          },
                  ),
                ),
              ),
            ],
          ),
          if (provider.totalResults > 0)
            Padding(
              padding: const EdgeInsets.only(top: 2, left: 28),
              child: Text(
                '${provider.totalResults} results',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildResultsList(
    SearchProvider provider,
    ThemeData theme,
    SettingsProvider settings,
  ) {
    if (provider.searchState == LoadState.idle && provider.works.isEmpty) {
      final List<String> suggestedTopics = [
        'Artificial Intelligence',
        'Machine Learning',
        'Data Science',
        'Quantum Computing',
        'Cybersecurity',
        'Blockchain',
        'Internet of Things',
        'Cloud Computing',
        'Augmented Reality',
        'Bioinformatics',
      ];

      return SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: [
                  Icon(
                    Icons.explore_outlined,
                    size: 64,
                    color: theme.colorScheme.primary.withOpacity(0.5),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Discover Research Trends',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Search for topics or choose from suggestions below',
                    style: TextStyle(color: theme.colorScheme.onSurfaceVariant),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 32),
                ],
              ),
            ),
            if (provider.searchHistory.isNotEmpty) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Recent Searches',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  TextButton(
                    onPressed: () =>
                        context.read<SearchProvider>().clearHistory(),
                    child: const Text('Clear all'),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8.0,
                runSpacing: 4.0,
                children: provider.searchHistory.map((query) {
                  return InputChip(
                    avatar: const Icon(Icons.history, size: 16),
                    label: Text(query),
                    deleteIcon: const Icon(Icons.close, size: 14),
                    onDeleted: () =>
                        context.read<SearchProvider>().removeFromHistory(query),
                    onPressed: () {
                      _searchController.text = query;
                      _performSearch();
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 24),
            ],
            if (provider.personalizedTopics.isNotEmpty) ...[
              Row(
                children: [
                  Icon(
                    Icons.auto_awesome,
                    size: 18,
                    color: theme.colorScheme.primary,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    'Recommend for You',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              const SizedBox(height: 12),
              ...provider.personalizedTopics.map((topic) {
                final authors = provider.personalizedAuthors[topic] ?? [];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ActionChip(
                        avatar: Icon(
                          Icons.local_fire_department,
                          size: 16,
                          color: theme.colorScheme.primary,
                        ),
                        label: Text(topic),
                        onPressed: () {
                          AnalyticsService.logForYouTap(
                            type: 'topic',
                            value: topic,
                          );
                          _searchController.text = topic;
                          _performSearch();
                        },
                      ),
                      if (provider.personalizedState == LoadState.loading &&
                          authors.isEmpty)
                        const Padding(
                          padding: EdgeInsets.only(top: 8),
                          child: SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        )
                      else if (authors.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8.0,
                          runSpacing: 8.0,
                          children: authors.map((author) {
                            return ActionChip(
                              avatar: Icon(
                                Icons.person_outline,
                                size: 16,
                                color: theme.colorScheme.secondary,
                              ),
                              label: Text(author.displayName),
                              onPressed: () {
                                if (author.authorId == null) return;
                                AnalyticsService.logForYouTap(
                                  type: 'author',
                                  value: author.displayName,
                                );
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => AuthorDetailScreen(
                                      authorId: author.authorId!,
                                      authorName: author.displayName,
                                    ),
                                  ),
                                );
                              },
                            );
                          }).toList(),
                        ),
                      ],
                    ],
                  ),
                );
              }),
              const SizedBox(height: 16),
            ],
            if (settings.showSuggestedTopics) ...[
              Text(
                'Suggested Topics',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8.0,
                runSpacing: 8.0,
                children: suggestedTopics.map((topic) {
                  return ActionChip(
                    avatar: Icon(
                      Icons.trending_up,
                      size: 16,
                      color: theme.colorScheme.primary,
                    ),
                    label: Text(topic),
                    onPressed: () {
                      _searchController.text = topic;
                      _performSearch();
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 32),
            ],
            if (settings.showTopAuthors) ...[
              Text(
                'Top 10 Contributing Authors',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              if (provider.globalTopAuthorsState == LoadState.loading)
                const SizedBox(
                  height: 100,
                  child: Center(child: CircularProgressIndicator()),
                )
              else if (provider.globalTopAuthorsState == LoadState.error)
                Card(
                  elevation: 0,
                  color: theme.colorScheme.errorContainer.withOpacity(0.2),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(
                      color: theme.colorScheme.error.withOpacity(0.3),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.error_outline,
                          color: theme.colorScheme.error,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Failed to load top authors.',
                            style: TextStyle(
                              color: theme.colorScheme.onErrorContainer,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: () => context
                              .read<SearchProvider>()
                              .loadGlobalTopAuthors(),
                          child: const Text('Retry'),
                        ),
                      ],
                    ),
                  ),
                )
              else ...[
                Wrap(
                  spacing: 8.0,
                  runSpacing: 8.0,
                  children: provider.globalTopAuthors.map((author) {
                    return ActionChip(
                      avatar: Icon(
                        Icons.person,
                        size: 16,
                        color: theme.colorScheme.primary,
                      ),
                      label: Text(author.displayName),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AuthorDetailScreen(
                              authorId: author.id,
                              authorName: author.displayName,
                            ),
                          ),
                        );
                      },
                    );
                  }).toList(),
                ),
              ],
            ],
          ],
        ),
      );
    }

    if (provider.searchState == LoadState.loading && provider.works.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }

    if (provider.searchState == LoadState.error && provider.works.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 48, color: theme.colorScheme.error),
            const SizedBox(height: 16),
            Text(
              provider.errorMessage ?? 'An error occurred while fetching data',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _performSearch,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.all(12),
      itemCount: provider.works.length + 1,
      itemBuilder: (context, index) {
        if (index == provider.works.length) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton.icon(
                  onPressed: provider.currentPage > 1
                      ? () {
                          context.read<SearchProvider>().goToPage(
                            provider.currentPage - 1,
                          );
                          if (_scrollController.hasClients) {
                            _scrollController.animateTo(
                              0,
                              duration: const Duration(milliseconds: 300),
                              curve: Curves.easeInOut,
                            );
                          }
                        }
                      : null,
                  icon: const Icon(Icons.chevron_left, size: 20),
                  label: const Text('Prev'),
                ),
                const SizedBox(width: 16),
                Text(
                  'Page ${provider.currentPage}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(width: 16),
                ElevatedButton.icon(
                  onPressed: provider.hasMore
                      ? () {
                          context.read<SearchProvider>().goToPage(
                            provider.currentPage + 1,
                          );
                          if (_scrollController.hasClients) {
                            _scrollController.animateTo(
                              0,
                              duration: const Duration(milliseconds: 300),
                              curve: Curves.easeInOut,
                            );
                          }
                        }
                      : null,
                  label: const Text('Next'),
                  icon: const Icon(Icons.chevron_right, size: 20),
                ),
              ],
            ),
          );
        }

        final work = provider.works[index];
        final readingList = context.watch<ReadingListProvider>();
        final isSaved = readingList.contains(work.id);
        return Card(
          elevation: 2,
          margin: const EdgeInsets.symmetric(vertical: 6),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => DetailScreen(workId: work.id),
                ),
              );
            },
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(
                          work.title,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (work.isOpenAccess)
                        Container(
                          margin: const EdgeInsets.only(left: 8),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.green.shade100,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            'OA',
                            style: TextStyle(
                              color: Colors.green.shade800,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      IconButton(
                        icon: Icon(
                          isSaved ? Icons.bookmark : Icons.bookmark_border,
                        ),
                        color: isSaved ? theme.colorScheme.primary : null,
                        iconSize: 20,
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                        onPressed: () =>
                            context.read<ReadingListProvider>().toggle(work),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (work.authorships.isNotEmpty) ...[
                    Text(
                      work.authorships.map((e) => e.authorName).join(', '),
                      style: TextStyle(
                        color: theme.colorScheme.onSurfaceVariant,
                        fontSize: 13,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                  ],
                  Row(
                    children: [
                      if (work.publicationYear != null) ...[
                        Icon(
                          Icons.calendar_today,
                          size: 14,
                          color: theme.colorScheme.outline,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${work.publicationYear}',
                          style: TextStyle(
                            color: theme.colorScheme.outline,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(width: 16),
                      ],
                      Icon(
                        Icons.format_quote,
                        size: 14,
                        color: theme.colorScheme.outline,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'Citations: ${work.citedByCount}',
                        style: TextStyle(
                          color: theme.colorScheme.outline,
                          fontSize: 12,
                        ),
                      ),
                      if (work.primarySource?.displayName != null) ...[
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            work.primarySource!.displayName,
                            style: TextStyle(
                              color: theme.colorScheme.primary,
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                            ),
                            textAlign: TextAlign.end,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showSettingsModal(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) {
        return _SettingsDialog();
      },
    );
  }
}

class _SettingsDialog extends StatelessWidget {
  static const List<Color> _themeColors = [
    Color(0xFF1D9E75), // Default green
    Color(0xFF2196F3), // Blue
    Color(0xFF9C27B0), // Purple
    Color(0xFFE91E63), // Pink
    Color(0xFFFF9800), // Orange
    Color(0xFF009688), // Teal
    Color(0xFF3F51B5), // Indigo
    Color(0xFF795548), // Brown
    Color(0xFF607D8B), // Blue Grey
    Color(0xFFF44336), // Red
    Color(0xFF4CAF50), // Light Green
    Color(0xFF00BCD4), // Cyan
  ];

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final theme = Theme.of(context);

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Settings',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 24),
            // Theme Color
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Theme', style: theme.textTheme.bodyLarge),
                GestureDetector(
                  onTap: () => _showColorPicker(context, settings),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: settings.seedColor,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: theme.colorScheme.outline.withOpacity(0.3),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.palette,
                          size: 16,
                          color: Colors.white,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'Pick color',
                          style: theme.textTheme.labelMedium?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 8),
            // Suggested Topics Toggle
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    'Suggested Topics',
                    style: theme.textTheme.bodyLarge,
                  ),
                ),
                Switch(
                  value: settings.showSuggestedTopics,
                  onChanged: (v) => settings.setShowSuggestedTopics(v),
                ),
              ],
            ),
            // Top Contributing Authors Toggle
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    'Top contributing authors',
                    style: theme.textTheme.bodyLarge,
                  ),
                ),
                Switch(
                  value: settings.showTopAuthors,
                  onChanged: (v) => settings.setShowTopAuthors(v),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showColorPicker(BuildContext context, SettingsProvider settings) {
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Choose Theme Color'),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          content: SizedBox(
            width: 280,
            child: Wrap(
              spacing: 12,
              runSpacing: 12,
              alignment: WrapAlignment.center,
              children: _themeColors.map((color) {
                final isSelected = settings.seedColor.value == color.value;
                return GestureDetector(
                  onTap: () {
                    settings.setSeedColor(color);
                    Navigator.pop(ctx);
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: isSelected ? Colors.white : Colors.transparent,
                        width: 3,
                      ),
                      boxShadow: isSelected
                          ? [
                              BoxShadow(
                                color: color.withOpacity(0.5),
                                blurRadius: 8,
                                spreadRadius: 2,
                              ),
                            ]
                          : [],
                    ),
                    child: isSelected
                        ? const Icon(Icons.check, color: Colors.white, size: 24)
                        : null,
                  ),
                );
              }).toList(),
            ),
          ),
        );
      },
    );
  }
}
